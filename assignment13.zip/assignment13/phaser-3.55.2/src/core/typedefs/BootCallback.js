/**
 * @callback Phaser.Types.Core.BootCallback
 * @since 3.0.0
 *
 * @param {Phaser.Game} game - The game.
 */
